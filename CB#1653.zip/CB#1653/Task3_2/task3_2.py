############## Task3.2 - Emulation ##############

import vrep
import sys
import time

import math
import numpy as np
import cv2
import cv2.aruco as aruco
import time
from ArUco_library import *

################ Initialization of handles. Do not change the following section ###################################

vrep.simxFinish(-1)

clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5)

if clientID!=-1:
	print "connected to remote api server"
else:
	print 'connection not successful'
	sys.exit("could not connect")

returnCode,sparkv_handle=vrep.simxGetObjectHandle(clientID,'TRUCK',vrep.simx_opmode_oneshot_wait)
vrep.simxStartSimulation(clientID,vrep.simx_opmode_oneshot_wait)

#####################################################################################################################


cap = cv2.VideoCapture("input_video.avi")
flag = 0
l = 2.46 #arena length in meters of the actual arena
w = 1.81 #arena width in meters of the actual arena
top_left_w = 0
top_left_h = 0
bottom_right_w = 1280    #actual no of pixels in image in each row
bottom_right_h = 720     #actual no of pixels in image in each column
emptyBuff = bytearray()

while(cap.isOpened()):
        ret, frame = cap.read()
        
	if ret==False:
                break
	
	frame = frame[top_left_h:bottom_right_h, top_left_w:bottom_right_w]

        Detected_ArUco_markers = detect_ArUco(frame)
	
	if len(Detected_ArUco_markers) !=3 and len(Detected_ArUco_markers) !=1:
		continue
	
	angle = Calculate_orientation_in_degree(Detected_ArUco_markers)

	if flag == 0:
		top_left_w = int(Detected_ArUco_markers[10][0][0] + Detected_ArUco_markers[10][2][0])/2
		top_left_h = int(Detected_ArUco_markers[10][0][1] + Detected_ArUco_markers[10][2][1])/2
		bottom_right_w = int(Detected_ArUco_markers[11][0][0] + Detected_ArUco_markers[11][2][0])/2
		bottom_right_h = int(Detected_ArUco_markers[11][0][1] + Detected_ArUco_markers[11][2][1])/2
		n = abs(top_left_h - bottom_right_h)
		m = abs(top_left_w - bottom_right_w)
		pixel_length = l/m
		pixel_width = w/n
		flag=1

	####robot position
	xr = int(Detected_ArUco_markers[1][0][0] + Detected_ArUco_markers[1][2][0])/2   #Actual length in pixel
	yr = int(Detected_ArUco_markers[1][0][1] + Detected_ArUco_markers[1][2][1])/2   #  ''     ''   ''   ''
	pxr = xr*pixel_length   #pixel to meters
	pyr = yr*pixel_width	#  ''  ''   ''   
	npxr = -pxr + 1.5  #fitting to vrep coordinate system
	npyr = pyr - 1.0  #  ''    ''  ''      ''       ''
	
	####robot orientation
	alpha = 0
	beta = 0
	gamma = angle[1]
	gamma = gamma-180
	gamma = math.radians(gamma)
	
	###resetting dynamics
	ret = vrep.simxCallScriptFunction(clientID,'LuaFunctions',vrep.sim_scripttype_childscript,'reset',[],[],[],emptyBuff, vrep.simx_opmode_oneshot)

	##changing position and orientation of sparkv in simulation
	returnCode = vrep.simxSetObjectOrientation(clientID,sparkv_handle,-1,[alpha, beta, gamma],vrep.simx_opmode_oneshot)
	returnCode = vrep.simxSetObjectPosition(clientID,sparkv_handle,-1,[npxr, npyr, 0.0290],vrep.simx_opmode_oneshot)
	
	
        frame = mark_ArUco(frame,Detected_ArUco_markers,angle)
	
        #cv2.namedWindow('image', cv2.WINDOW_NORMAL)
	#cv2.resizeWindow('image', 864, 600)	
        cv2.imshow('image',frame)
        cv2.waitKey(1)

cap.release()
cv2.destroyAllWindows()

#end of simulation
returnCode = vrep.simxSetObjectPosition(clientID,sparkv_handle,-1,[0, 0, 0.0290],vrep.simx_opmode_oneshot)
vrep.simxStopSimulation(clientID,vrep.simx_opmode_oneshot_wait)
